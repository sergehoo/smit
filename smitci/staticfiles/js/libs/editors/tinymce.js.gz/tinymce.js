/** Tinymce */
@@include('@@nodeRoot/../../node_modules/tinymce/tinymce.min.js')
@@include('@@nodeRoot/../../node_modules/tinymce/themes/silver/theme.min.js')
@@include('@@nodeRoot/../../node_modules/tinymce/icons/default/icons.min.js')