create function st_longestline(geom1 geometry, geom2 geometry) returns geometry
    immutable
    strict
    parallel safe
    cost 5000
    language sql
as
$$SELECT public._ST_LongestLine(public.ST_ConvexHull($1), public.ST_ConvexHull($2))$$;

comment on function st_longestline(geometry, geometry) is 'args: g1, g2 - Returns the 2D longest line between two geometries.';

alter function st_longestline(geometry, geometry) owner to postgres;

