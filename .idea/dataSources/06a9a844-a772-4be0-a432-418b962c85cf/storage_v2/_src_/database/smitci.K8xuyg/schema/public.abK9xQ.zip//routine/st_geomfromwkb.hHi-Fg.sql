create function st_geomfromwkb(bytea, integer) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language sql
as
$$SELECT public.ST_SetSRID(public.ST_GeomFromWKB($1), $2)$$;

alter function st_geomfromwkb(bytea, integer) owner to postgres;

